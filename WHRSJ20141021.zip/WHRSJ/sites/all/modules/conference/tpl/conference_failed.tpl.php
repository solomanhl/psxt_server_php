<?php
?>
<f id_f="<?php print $failed->code; ?>" name_f="<?php print $failed->name; ?>" company_f="<?php print $failed->company; ?>" />
