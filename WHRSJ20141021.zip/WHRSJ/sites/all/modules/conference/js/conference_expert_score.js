function myrefresh() 
{ 
       window.location.reload(); 
} 
setTimeout('myrefresh()',10000); //指定10秒刷新一次