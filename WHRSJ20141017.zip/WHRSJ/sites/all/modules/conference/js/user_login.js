

Drupal.behaviors.userLoginBehavior = function (context) {
	
	var autoname = $('#edit-name').autocomplete({ 
	    serviceUrl:'/user/autocomplete.json',
	    minChars:2
	  });
	
	autoname.enable();
}