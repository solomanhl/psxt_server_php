<?php
?>
<ext
	id="<?php print $score->code; ?>"
	pogejielun="<?php print $score->pgresult; ?>"
	opinion=""
	group_score=""
	pinjunfen="<?php print $score->bjtype; ?>"
	noeduc="<?php print $score->noeduc; ?>"
	dbresult="<?php print $score->dbresult; ?>"
/>