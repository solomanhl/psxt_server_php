<div style="text-align:center;">
<div><font size="7" face="新宋体" color="#000000"></font></div>
<br />
<br />	
</div>